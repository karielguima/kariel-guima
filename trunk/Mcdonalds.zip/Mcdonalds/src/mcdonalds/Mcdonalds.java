package mcdonalds;

public class Mcdonalds {
         
    public static void main(String[] args) {
        
    }
    
}